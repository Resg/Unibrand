Background video for Hero section.
File: promo.mp4 (web-optimized).